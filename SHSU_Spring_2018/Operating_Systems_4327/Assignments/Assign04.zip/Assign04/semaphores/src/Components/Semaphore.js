import { Component } from "react"

const Semaphore = (props) =>{
    return (

    )
}
export default Semaphore