import React, { Component } from "react"
import ButtonE from "./Components/ButtonE"

class Parent extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    return (
      <div className="Parent">
        <ButtonE
          onClick={this.props.incParentIncome}
          text="Increment Parent Income"
        />
        <ButtonE
          onClick={this.props.decrParentIncome}
          text="Decrement Parent Income"
        />
        {/* <ButtonE
          onClick={this.props.incrNumParents}
          text="Increment Number of Parents"
        />
        <ButtonE
          onClick={this.props.decrNumParents}
          text="Decrement Number of Parents"
        /> */}
      </div>
    )
  }
}

export default Parent
