import React, { Component } from "react"
import ButtonE from "./Components/ButtonE"

class Child extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    return (
      <div className="Child">
        <ButtonE
          onClick={this.props.incChildwithdrawals}
          text="Increment Child Withdrawls"
        />
        <ButtonE
          onClick={this.props.decrChildwithdrawals}
          text="Decrement Child Withdrawls"
        />
        <ButtonE
          onClick={this.props.incrNumChildren}
          text="Increment Number of Children"
        />
        <ButtonE
          onClick={this.props.decrNumChildren}
          text="Decrement Number of Children"
        />
      </div>
    )
  }
}

export default Child
