import React, { Component } from "react"

class Child extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.handleClick = this.handleClick.bind(this)
  }

  handleClick(e) {
    this.props.handleIncrement(e.currentTarget.dataset.key)
  }

  render() {
    return (
      <div>
        <span>{this.props.item.value}</span>
        <button data-key={this.props.item.key} onClick={this.handleClick}>inc</button>
      </div>
    );
  }

}

class Parent extends React.Component {

  render() {
    return (
      <div>
        {
          this.props.list.map((item) => <Child item={item} handleIncrement={this.props.handleIncrement} />)
        }
      </div>
    );
  }

}

class GrandParent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [
        {
          key: 'one',
          value: 1
        },
        {
          key: 'two',
          value: 2
        },
        {
          key: 'three',
          value: 3
        }
      ]
    };

    this.handleIncrement = this.handleIncrement.bind(this)
  }

  handleIncrement(key) {
    this.setState({
        list: this.state.list.map((l) => {
        if (l.key === key) {
            return {key: l.key, value: l.value + 1}
        }
        return l
      })
    })
  }

  render() {
    return (<Parent list={this.state.list} handleIncrement={this.handleIncrement} />);
  }

}

// React.render(<GrandParent />, document.getElementById('container'));