import React, { Component } from 'react'
import './App.css'

import Parent from './Parent'
import Child from './Child'

class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      parentIncome: 1,
      childwithdrawals: 1,
      BankTotal: 0,
      numParents: 2,
      numChildren: 2,
    }
  }

  componentDidMount() {
    console.log('ticking')
    this.tick()
  }

  incrementBank = (amnt) => {
    this.setState({ BankTotal: this.state.BankTotal + amnt })
  }

  decrementBank = (amnt) => {
    this.setState({
      BankTotal: this.state.BankTotal - amnt < 0 ? 0 : this.state.BankTotal - amnt,
    })
  }

  incChildwithdrawals = () => {
    this.setState({ childwithdrawals: this.state.childwithdrawals + 1 })
  }
  decrChildwithdrawals = () => {
    this.setState({
      childwithdrawals: this.state.childwithdrawals - 1 < 0 ? 0 : this.state.childwithdrawals - 1,
    })
  }
  incNumChildren = () => {
    this.setState({ numChildren: this.state.numChildren + 1 })
  }
  decrNumChildren = () => {
    this.setState({
      numChildren: this.state.numChildren - 1 < 0 ? 0 : this.state.numChildren - 1,
    })
  }

  incParentIncome = () => {
    this.setState({ parentIncome: this.state.parentIncome + 1 })
  }
  decrParentIncome = () => {
    this.setState({
      parentIncome: this.state.parentIncome - 1 < 0 ? 0 : this.state.parentIncome - 1,
    })
  }
  incNumParents = () => {
    this.setState({ numParents: this.state.numParents + 1 })
  }
  decrNumParents = () => {
    this.setState({
      numParents: this.state.numParents - 1 < 0 ? 0 : this.state.numParents - 1,
    })
  }

  tick() {
    setInterval(() => {
      this.incrementBank(this.state.parentIncome * this.state.numParents / 100)

      for (let i = 0; i < this.state.numChildren; i += 1) {
        // if can decrement by 1, decrement.
        if (this.state.BankTotal - this.state.childwithdrawals >= 0) {
          this.setState({
            BankTotal: this.state.BankTotal - this.state.childwithdrawals / 100,
          })
        }
      }
    }, 10)
  }

  render() {
    return (
      <div className="App">
        <h1>Bank Total: {this.state.BankTotal.toFixed(2)}</h1>
        <h2>
          Income Per Second:{' '}
          {this.state.parentIncome * this.state.numParents -
            this.state.childwithdrawals * this.state.numChildren}
        </h2>
        <div className="InfoContainer">
          <div className="ParentInfo">
            <h4>Number of Parents: {this.state.numParents}</h4>
            <h4>Amnt Each Parent Earns: {this.state.parentIncome}</h4>
            <h3>Total Income: {this.state.parentIncome * this.state.numParents}</h3>
          </div>
          <div className="ChildInfo">
            <h4>Number of Children: {this.state.numChildren}</h4>
            <h4>Amnt Each Child Withdraws: {this.state.childwithdrawals}</h4>
            <h3>Total Withdrawals: {this.state.childwithdrawals * this.state.numChildren}</h3>
          </div>
        </div>

        <div className="ButtonsContainer">
          <Parent
            parentIncome={this.state.parentIncome}
            incrementBank={this.incrementBank}
            BankTotal={this.state.BankTotal}
            incParentIncome={this.incParentIncome}
            decrParentIncome={this.decrParentIncome}
            incrNumParents={this.incNumParents}
            decrNumParents={this.decrNumParents}
          />
          <Child
            childwithdrawals={this.state.childwithdrawals}
            decrementBank={this.decrementBank}
            BankTotal={this.state.BankTotal}
            incChildwithdrawals={this.incChildwithdrawals}
            decrChildwithdrawals={this.decrChildwithdrawals}
            incrNumChildren={this.incNumChildren}
            decrNumChildren={this.decrNumChildren}
          />
        </div>
      </div>
    )
  }
}

export default App
