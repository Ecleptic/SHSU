import React from 'react'
import styled from 'styled-components'

const Button = styled.button`
  /* This renders the buttons above... Edit me! */
  display: inline-block;
  border-radius: 15px;
  padding: 0.5rem;
  margin: 0.5rem 1rem;
  width: 11rem;
  background: transparent;
  //   background: blue;
  color: black;
  border: 2px solid blue;
  &:hover {
    background: #00009090;
    color: blue;
  }
  &:active {
    box-shadow: 12px 12px 2px 1px #00009090;
  }
`
const ButtonE = props => <Button onClick={props.onClick}> {props.text} </Button>

export default ButtonE
