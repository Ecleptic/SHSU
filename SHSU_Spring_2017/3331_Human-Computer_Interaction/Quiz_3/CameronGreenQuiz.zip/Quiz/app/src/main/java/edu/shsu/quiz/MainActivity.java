package edu.shsu.quiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


/*
*** NOTES FOR REFERENCE ***
*
* https://developer.android.com/guide/topics/ui/dialogs.html
* https://www.androidtutorialpoint.com/basics/android-alert-dialog-tutorial-working-time-picker-date-picker-list-dialogs/
* http://www.mkyong.com/android/android-custom-dialog-example/
* */

public class MainActivity extends AppCompatActivity {

    final Context context = this;
    private Button button;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.buttonShowCustomDialog);

        // add button listener
        button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                // dialog_box dialog
                final Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.dialog_box);
                dialog.setTitle("HCI Class!");

                // set the dialog_box dialog components - text, image and button
                TextView text = (TextView) dialog.findViewById(R.id.textView);
                text.setText("This Class is Fun!");

                TextView textTitle = (TextView) dialog.findViewById(R.id.textTitle);
                textTitle.setText("HCI Class!");

                ImageView image = (ImageView) dialog.findViewById(R.id.image);
                image.setImageResource(R.drawable.ic_launcher);

                Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                // if button is clicked, close the dialog_box dialog
                dialogButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });
    }
}
